These animations:

- mac_ee_lin_MNIST.gif: t-SNE embedding with F = neural net mapping.

- mac_tsne_nn_MNIST.gif EE embedding with F = linear mapping.

show the progress of the MAC optimization over iterations. The left panel
shows the auxiliary coordinates Z = (z1,...,zN) for every data point. The
right panel shows the output of the mapping F(Y) = (F(y1),...,F(yN)). At
the beginning, Z and F(Y) disagree, since F cannot produce the ideal Z
(the free embedding), and the MAC optimization progressively modifies Z
and F so that upon convergence they agree and minimize the parametric
embedding objective function P(F). The dataset is 60000 points from MNIST,
projected to 2D.

All these animations may be seen with a web browser or with specialized
GIF image viewers.

